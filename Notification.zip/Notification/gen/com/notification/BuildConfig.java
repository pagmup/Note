/** Automatically generated file. DO NOT MODIFY */
package com.notification;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}