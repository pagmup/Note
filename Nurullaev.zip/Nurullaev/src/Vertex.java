import java.util.ArrayList;

public class Vertex {
	
	private int weight;
	private ArrayList<Neighboring> neighboringList;
	
	public Vertex() {
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getWeight() {
		return this.weight;
	}
	public ArrayList<Neighboring> getNeighboring() {
		return this.neighboringList;
	}
	public void setNeighboring(ArrayList<Neighboring> neighboringList) {
		this.neighboringList = neighboringList;
	}
}
