import java.util.ArrayList;

public class Vertex {
	private String name;
	private boolean passed;
	private int pathLength;
	private ArrayList<Neighboring> neighboringList;
	
	public Vertex(String name) {
		this.name = name;
	}
	public String getName() {
		return this.name;
	}
	public void setPassed(boolean passed) {
		this.passed = passed;
	}
	public boolean getPassed() {
		return this.passed;
	}
	public void setPathLength(int weight) {
		this.pathLength = weight;
	}
	public int getPathLength() {
		return this.pathLength;
	}
	public ArrayList<Neighboring> getNeighboring() {
		return this.neighboringList;
	}
	public void setNeighboring(ArrayList<Neighboring> neighboringList) {
		this.neighboringList = neighboringList;
	}
}
