import java.util.Comparator;

public class customComparator implements Comparator<Neighboring>{
    public int compare( Neighboring neigh1,  Neighboring neigh2) {
        return (neigh1.getVertex().getPathLength() > neigh2.getVertex().getPathLength() ? 1 : ( neigh1.getVertex().getPathLength() == neigh2.getVertex().getPathLength() ? 0 : -1));
    }
}