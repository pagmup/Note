
public class Edge {
	private int weight;
	private Vertex vertexOne;
	private Vertex vertexTwo;
	
	public Edge(Vertex vertexOne, Vertex vertexTwo, int weight) {
		this.vertexOne = vertexOne;
		this.vertexTwo = vertexTwo;
		this.weight = weight;
	}
	public Vertex getVertexOne() {
		return this.vertexOne;
	}
	public Vertex getVertexTwo() {
		return this.vertexTwo;
	}
	public int getWeight() {
		return this.weight;
	}
	public void setVertexOne(Vertex vertexOne) {
		this.vertexOne = vertexOne;
	}
	public void setVertexTwo(Vertex vertexTwo) {
		this.vertexTwo = vertexTwo;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
}
