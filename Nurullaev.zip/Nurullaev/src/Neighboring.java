
public class Neighboring {
	private Vertex vertex;
	private Edge edge;
	public Neighboring(Vertex vertex, Edge edge) {
		this.vertex = vertex;
		this.edge = edge;
	}
	public Vertex getVertex() {
		return this.vertex;
	}
	public Edge getEdge() {
		return this.edge;
	}
}
