import java.util.ArrayList;
import java.util.Arrays;

public class Graph
{
	public static void main(String[] args){
		
		Vertex a = new Vertex();
		Vertex b = new Vertex();
		Vertex c = new Vertex();
		Vertex d = new Vertex();
		Vertex e = new Vertex();
		Vertex f = new Vertex();


		Edge ab = new Edge(a, b, 2);
		Edge ac = new Edge(a, c, 2);
		Edge ad = new Edge(a, d, 1);
		
		Edge bc = new Edge(b, c, 4);
		Edge bf = new Edge(b, f, 3);
		Edge ba = new Edge(b, a, 2);

		Edge ca = new Edge(c, a, 2);
		Edge cb = new Edge(c, b, 4);
		Edge cd = new Edge(c, d, 3);
		Edge cf = new Edge(c, f, 1);
		
		Edge da = new Edge(d, a, 1);
		Edge dc = new Edge(d, c, 3);
		Edge de = new Edge(d, e, 2);

		Edge ed = new Edge(d, d, 2);
		Edge ef = new Edge(e, f, 4);

		Edge fb = new Edge(f, b, 3);
		Edge fc = new Edge(f, c, 1);
		Edge fe = new Edge(f, e, 4);

		a.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(b, ab), 
								new Neighboring(c, ac), 
								new Neighboring(d, ad))));
		b.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(a, ba), 
								new Neighboring(c, bc), 
								new Neighboring(f, bf))));
		c.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(a, ca), 
								new Neighboring(b, cb), 
								new Neighboring(d, cd), 
								new Neighboring(f, cf))));
		d.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(a, da), 
								new Neighboring(c, dc), 
								new Neighboring(e, de))));
		e.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(d, ed), 
								new Neighboring(f, ef))));
		f.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(b, fb), 
								new Neighboring(c, fc), 
								new Neighboring(e, fe))));
	}
}