import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

public class Graph
{
	public static void main(String[] args){
		
		Vertex a = new Vertex("a");
		Vertex b = new Vertex("b");
		Vertex c = new Vertex("c");
		Vertex d = new Vertex("d");
		Vertex e = new Vertex("e");
		Vertex f = new Vertex("f");


		Edge ab = new Edge(a, b, 2);
		Edge ac = new Edge(a, c, 2);
		Edge ad = new Edge(a, d, 1);
		
		Edge bc = new Edge(b, c, 4);
		Edge bf = new Edge(b, f, 3);
		Edge ba = new Edge(b, a, 2);

		Edge ca = new Edge(c, a, 2);
		Edge cb = new Edge(c, b, 4);
		Edge cd = new Edge(c, d, 3);
		Edge cf = new Edge(c, f, 1);
		
		Edge da = new Edge(d, a, 1);
		Edge dc = new Edge(d, c, 3);
		Edge de = new Edge(d, e, 2);

		Edge ed = new Edge(d, d, 2);
		Edge ef = new Edge(e, f, 4);

		Edge fb = new Edge(f, b, 3);
		Edge fc = new Edge(f, c, 1);
		Edge fe = new Edge(f, e, 4);

		a.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(b, ab), 
								new Neighboring(c, ac), 
								new Neighboring(d, ad))));
		b.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(a, ba), 
								new Neighboring(c, bc), 
								new Neighboring(f, bf))));
		c.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(a, ca), 
								new Neighboring(b, cb), 
								new Neighboring(d, cd), 
								new Neighboring(f, cf))));
		d.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(a, da), 
								new Neighboring(c, dc), 
								new Neighboring(e, de))));
		e.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(d, ed), 
								new Neighboring(f, ef))));
		f.setNeighboring(
				new ArrayList<Neighboring>(
						Arrays.asList(
								new Neighboring(b, fb), 
								new Neighboring(c, fc), 
								new Neighboring(e, fe))));
		String startPoint = "a";
		String endPoint = "f";
		Vertex vertexStart = new Vertex(startPoint);
		Vertex vertexEnd = new Vertex(endPoint);
		switch (startPoint) {
		case "a":
			vertexStart = a;
			break;
		case "b":
			vertexStart = b;
			break;
		case "c":
			vertexStart = c;
			break;
		case "d":
			vertexStart = d;
			break;
		case "e":
			vertexStart = e;
			break;
		case "f":
			vertexStart = f;
			break;
		default:
			break;
		}
		switch (endPoint) {
		case "a":
			vertexEnd = a;
			break;
		case "b":
			vertexEnd = b;
			break;
		case "c":
			vertexEnd = c;
			break;
		case "d":
			vertexEnd = d;
			break;
		case "e":
			vertexEnd = e;
			break;
		case "f":
			vertexEnd = f;
			break;
		default:
			break;
		}
		
		//vertexStart.getNeighboring().get(0).getVertex().setPassed(false);
		vertexStart.setPathLength(0);
		
		System.out.print(calculatePathLength(vertexStart, vertexEnd));
		
		
	}
	public static ArrayList<Neighboring> deletePassedVertex(ArrayList<Neighboring> neighborings) {
		for(Iterator<Neighboring> neighIter = neighborings.iterator(); neighIter.hasNext();) {
			Neighboring currentNeigh = neighIter.next();
			if(currentNeigh.getVertex().getPassed() == true) {
				neighIter.remove();
			}
		}
		return neighborings;
	}
	public static String calculatePathLength(Vertex vertexStart, Vertex vertexEnd) {
		ArrayList<Neighboring> neighborings = deletePassedVertex(vertexStart.getNeighboring());
		//if (neighborings.get(0).getVertex().getName() == "d")
		//{
		//	System.out.println("�������� ������� �������� �������: " + neighborings.get(0).getVertex().getName());
		//}
		if(neighborings.size() > 0) {
			Collections.sort(neighborings, new customComparator());
			for(Neighboring neigh:neighborings) {
				if (neigh.getVertex() != vertexEnd) {
					//System.out.println(neigh.getEdge().getWeight());
					if(neigh.getVertex().getPathLength() == 0 || neigh.getVertex().getPathLength() >= vertexStart.getPathLength() + neigh.getEdge().getWeight()) {
						neigh.getVertex().setPathLength(vertexStart.getPathLength() + neigh.getEdge().getWeight());
						//System.out.println(neigh.getVertex().getName() + " - " + neigh.getVertex().getPathLength());
					}	
				} else {
					return "����� �� �������� �������";
				}
			}
			vertexStart.setPassed(true);	
			Collections.sort(neighborings, new customComparator());
			System.out.print(neighborings.get(0).getVertex().getName());
			/*System.out.println(neighborings.get(0).getVertex().getPathLength());
			System.out.print(neighborings.get(1).getVertex().getName());
			System.out.println(neighborings.get(1).getVertex().getPathLength());*/
			calculatePathLength(neighborings.get(0).getVertex(), vertexEnd);
		} else {
			return "��� ������� ��������";
		}
		return "";
	}
}